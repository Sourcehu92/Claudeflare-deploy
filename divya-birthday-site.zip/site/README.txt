Divya's 20th Birthday site — static, no build step.
Host: upload this folder to Netlify / Vercel / GitHub Pages / any web host (index.html at root).
Local test: open index.html, or run `python3 -m http.server` in this folder.
Replace assets/divya.jpg and assets/solo.mp3 to change photo/song (keep filenames).
Note: browsers need one tap to start audio, so the entry screen "tap" starts the song.
