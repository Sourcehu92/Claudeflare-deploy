(() => {
  const body = document.body, intro = document.getElementById('intro');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const audio = new Audio('assets/solo.mp3');   // no element in the DOM -> nothing visible
  audio.loop = true; audio.preload = 'auto'; audio.volume = 0;

  let started = false;
  function begin() {
    if (started) return; started = true;
    audio.play().then(() => fade(audio, .7, 3500)).catch(() => {});
    intro.classList.add('go');                       // lamp descends + light
    setTimeout(() => intro.classList.add('flash'), reduce ? 200 : 2900);   // light floods
    setTimeout(() => {
      intro.classList.add('done');
      body.classList.remove('locked'); body.classList.add('open');
      heart.start(); observe();
    }, reduce ? 400 : 3500);
  }
  function fade(a, to, ms) {
    const t0 = performance.now(), v0 = a.volume;
    (function s(t) { const k = Math.min(1, (t - t0) / ms); a.volume = v0 + (to - v0) * k; if (k < 1) requestAnimationFrame(s); })(t0);
  }
  intro.addEventListener('click', begin);
  intro.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') begin(); });

  function observe() {
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .2 });
    document.querySelectorAll('.reveal').forEach(el => io.observe(el));
  }

  /* ---------- 3D heart: dependency-free, ~1.6k points on the heart surface, projected on a 2D canvas ---------- */
  const heart = (() => {
    const cv = document.getElementById('heart'), ctx = cv.getContext('2d', { alpha: true });
    let W, H, dpr, pts = [], running = false, t0 = 0, scroll = 0;
    const N = innerWidth < 700 ? 1800 : 3200;

    // heart surface: x=16sin^3(u), y=13cos u-5cos2u-2cos3u-cos4u, thickness scaled by profile, rotated about Y
    function build() {
      pts = [];
      for (let i = 0; i < N; i++) {
        const u = Math.random() * Math.PI * 2, v = (Math.random() * 2 - 1);
        const s = Math.sin(u), c = Math.cos(u);
        const x = 16 * s ** 3, y = 13 * c - 5 * Math.cos(2 * u) - 2 * Math.cos(3 * u) - Math.cos(4 * u);
        const r = Math.sqrt(1 - v * v) * (.55 + .45 * Math.abs(s)) * 6.5; // z bulge
        const k = .55 + .45 * Math.sqrt(Math.random());                    // fill toward centre
        pts.push({ x: x * k / 16, y: y * k / 16, z: v * r / 16 * k, a: Math.random(), d: Math.random() * .6 });
      }
    }
    function size() {
      dpr = Math.min(devicePixelRatio || 1, 2);
      W = cv.width = innerWidth * dpr; H = cv.height = innerHeight * dpr;
    }
    addEventListener('resize', size);
    addEventListener('scroll', () => { scroll = Math.min(1, scrollY / innerHeight); }, { passive: true });
    const ease = t => 1 - Math.pow(1 - t, 3);

    function frame(now) {
      if (!running) return;
      const t = Math.max(0, (now - t0) / 1000);
      ctx.clearRect(0, 0, W, H);
      const open = ease(Math.min(1, t / 3.2));                     // heart "opens" from a spark
      const beat = 1 + .045 * Math.pow(Math.sin(t * 2.4), 6) * 2 + .02 * Math.sin(t * 1.2);
      const base = Math.min(W, H) * (innerWidth < 700 ? .22 : .18);
      const sc = base * open * beat * (1 - scroll * .35);
      const cx = W / 2, cy = H * (.27 - scroll * .1);
      const ry = Math.sin(t * .7) * .85, cr = Math.cos(ry), sr = Math.sin(ry);
      ctx.globalCompositeOperation = 'lighter';

      // soft aura
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, sc * 1.5);
      g.addColorStop(0, 'rgba(224,96,126,' + (.16 * open) + ')'); g.addColorStop(1, 'rgba(224,96,126,0)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

      const alpha = (1 - scroll * .75);
      for (let i = 0; i < pts.length; i++) {
        const p = pts[i];
        const lp = Math.max(0, Math.min(1, (open - p.d * .5) / .5));  // staggered unfolding
        const x = p.x * lp, y = p.y * lp, z = p.z * lp;
        const X = x * cr + z * sr, Z = -x * sr + z * cr;               // rotate Y
        const persp = 1 / (1 - Z * .35);
        const px = cx + X * sc * persp, py = cy - y * sc * persp + Math.sin(t * 1.3 + p.a * 6) * 1.2 * dpr;
        const depth = (Z + .5);                                       // 0..1 nearer = brighter
        const r = (.8 + 1.1 * persp * (.6 + p.a * .6)) * dpr;
        const L = .35 + .65 * Math.max(0, Math.min(1, depth));
        ctx.fillStyle = `rgba(235,${(95 + 90 * (1 - L)) | 0},${(130 + 40 * (1 - L)) | 0},${((.18 + .5 * L) * alpha).toFixed(3)})`;
        ctx.fillRect(px - r / 2, py - r / 2, r, r);
      }
      requestAnimationFrame(frame);
    }
    return { start() { if (running) return; size(); build(); running = true; t0 = performance.now(); requestAnimationFrame(frame); },
             stop() { running = false; } };
  })();
  document.addEventListener('visibilitychange', () => { if (document.hidden) heart.stop(); else if (started && body.classList.contains('open')) heart.start(); });
})();
